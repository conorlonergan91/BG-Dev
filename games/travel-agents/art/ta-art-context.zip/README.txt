TRAVEL AGENTS: TAIWAN FOOD TOUR — AI MOCK-UP CONTEXT BUNDLE
Rebuilt 2026-08-11 · current theme: "Wacky Races, Taiwan-food edition"
(over-the-top, battle-hungry rival travel agents crafting the best tours).

HOW TO USE (see mockup-kickoffs.md step 1 for the full loop):
1. Upload EVERY .md in this zip to ChatGPT in one go, as context/knowledge.
2. Also upload the style-reference image FIG-CHAR-influencer.png — tell ChatGPT
   to MATCH its illustrated style (warm, characterful, hand-illustrated feel).
3. Then paste the per-asset kickoff prompts from mockup-kickoffs.md, one at a time.

WHAT'S INSIDE (all current on-disk versions):
- mockup-kickoffs.md   — the paste-ready per-asset prompts (characters, vendors/
                         dishes, tour heroes, map, box cover). START HERE.
- art-style.md         — the visual bible: the ONE look, palette, line, mood.
- card-backs.md        — the card-BACK direction (day = 菜市場/早市 morning market
                         w/ dignified elders + baskets; night = 夜市 night market
                         w/ lanterns). NOTE: the shipping backs are code-rendered;
                         this is the illustrated vision for later.
- character-art.md     — the six agents' portrait briefs.
- vendor-art.md        — the dish/vendor card art briefs.
- tour-art.md          — the tour (Booking) hero briefs.
- map-board.md         — the shared table map backdrop brief.
- character-boards.md  — the player-mat art notes.
- rulebook-figures.md  — the rulebook figure briefs.

BINDING RAILS (content, not AI-vs-human — still fully in force):
- 繁體 (Traditional Chinese) only, never Simplified.
- Secular; dignified locals — never caricature; faithful real dishes.
- English name first everywhere.
- The 2 Indigenous East-region dishes (E01 竹筒飯, E04 石板烤肉), and the warm-fixer
  framing of The Big Boss (老大) / The Old Councillor (里長伯), are consultant-gated
  before any final/print use — playtest mock-ups are fine.

CURRENT TERMS (so the art reads on-theme):
- The sourcing action is "MARKET RUN" (the local market), not "Visit".
- The vendor-win action is "SIGN UP", not "Bribe".
