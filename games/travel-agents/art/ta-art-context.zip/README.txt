Travel Agents: Taiwan — AI art-context bundle (ta-art-context.zip)
==================================================================

WHAT THIS IS
  Context to upload ONCE to ChatGPT (or another image tool) before generating the
  prototype artwork. Upload every .md in this zip as knowledge/context, then attach
  the style-reference PNG and paste the kickoff blocks ONE AT A TIME.

CONTENTS
  art-style.md          - the ONE-LOOK style anchor (cite in every prompt)
  mockup-kickoffs.md    - the paste-one-at-a-time kickoff blocks (START HERE)
  character-art.md      - the six characters brief
  vendor-art.md         - the 24 vendor (dish-hero) briefs
  tour-art.md           - the boarding-pass tour/booking briefs
  map-board.md          - the shared map board brief (backdrop direction)
  character-boards.md   - the per-player character-board layout brief
  rulebook-figures.md   - rulebook figure briefs
  FIG-CHAR-influencer.png - the STYLE-REFERENCE image (an approved character
                            mock-up; attach it and say "match this art style")

HOW TO USE (phone-friendly)
  1. Upload all the .md files above to ChatGPT in one go.
  2. Attach FIG-CHAR-influencer.png and tell the tool to MATCH THAT ART STYLE.
  3. Paste ONE kickoff block from mockup-kickoffs.md per generation.
  4. Send the PNGs back (or drop in games/travel-agents/build/mockups/) for
     key + fit + embed via tools/mockup/prep_mockup.py.

REGENERABLE
  This zip is a convenience bundle built from tracked files. Rebuild it any time a
  brief changes, from the repo root:

    python - <<'PY'
    import zipfile, pathlib
    art = pathlib.Path("games/travel-agents/art")
    mds = ["art-style.md","mockup-kickoffs.md","character-art.md","vendor-art.md",
           "tour-art.md","map-board.md","character-boards.md","rulebook-figures.md"]
    with zipfile.ZipFile(art/"ta-art-context.zip","w",zipfile.ZIP_DEFLATED) as z:
        z.write(__file__ if False else art/"README-zip.txt", "README.txt")  # or regenerate this note
        for m in mds: z.write(art/m, m)
        z.write(art/"mockups/FIG-CHAR-influencer.png", "FIG-CHAR-influencer.png")
    PY

  (Simplest: re-run the studio's build step / ask bg-ai-prompt to rebuild it.)

SENSITIVITY RAILS (still binding — about CONTENT, not AI-vs-human)
  Traditional 繁體 (never Simplified); secular only; dignified locals (charming
  exaggeration, never ethnic caricature); real dishes/places faithful. The two
  Indigenous dishes E01 竹筒飯 (bamboo-tube rice) and E04 石板烤肉 (stone-slab BBQ)
  are CONSULTANT-GATED even for mock-ups: generic + respectful placeholder only,
  no tribal iconography, no AI-invented Indigenous-language terms; a paid
  Paiwan/Rukai/Amis community consultant signs off before any such art is used.
