TRAVEL AGENTS: TAIWAN FOOD TOUR — AI MOCK-UP CONTEXT BUNDLE
Rebuilt 2026-08-12 (STUDIO-GHIBLI ART PIVOT) · theme: "Wacky Races, Taiwan-food edition"
(over-the-top, battle-hungry rival travel agents crafting the best tours).

>>> THE BIG CHANGE THIS REBUILD — the illustration hand is now STUDIO-GHIBLI-INSPIRED.
Everything ILLUSTRATED (characters, vendor dishes, ingredients, tour tickets, card backs, cover)
is now a warm, HAND-PAINTED Studio-Ghibli-inspired anime hand:
  - soft painterly light, gentle organic outlines (not a hard vector stroke), luminous colour;
  - FOOD rendered irresistibly DELICIOUS the famous "Ghibli food" way (glisten, soft steam,
    springy/juicy/crisp textures, generous abundance) — make the player hungry;
  - CHARACTERS caricatured with EXAGGERATED BODY FEATURES + big expressive faces;
  - deliberately NOT photoreal, and deliberately NOT the flat, generic "AI/ChatGPT cartoon" look
    the earlier mock-ups drifted into.
  - "Ghibli" = the FEEL only (warm hand-painted anime + delicious food). Do NOT copy any specific
    copyrighted frame, character, or film.

TWO STYLE TRACKS — KEEP THEM APART:
  1. ILLUSTRATIONS  -> the painterly GHIBLI hand above (all art on cards/backs/cover).
  2. FUNCTIONAL ICONS (FIG-ICON-<type>: 6 ingredients + follower + ticket) -> a SEPARATE, flat,
     bold EMOJI/STICKER track, unchanged by the pivot. They render at ~40 px and MUST read as flat
     emoji. Do NOT Ghibli-fy the icons.

HOW TO USE (see mockup-kickoffs.md step 1 for the full loop):
1. Upload EVERY .md in this zip to ChatGPT in one go, as context/knowledge.
2. STYLE REFERENCE: generate ONE new GHIBLI hero first (a character e.g. the Globetrotter, or the
   cover), approve it, then attach THAT as the style-reference image for everything else and tell
   ChatGPT to MATCH that exact hand.
   *** Do NOT use FIG-CHAR-influencer.png as the style reference. *** It is the OLD flat "ChatGPT
   cartoon" look we are moving away from; attaching it drags the art back to the old style. It is
   included here as CONTEXT/seed only (so you can see what NOT to reproduce). Re-do the six
   characters in the new Ghibli hand.
3. Then paste the per-asset kickoff prompts from mockup-kickoffs.md, one at a time.

>>> THE FUNCTIONAL ICONS (mockup-kickoffs.md -> "Icon set — FIG-ICON-*") — the emoji track.
The six ingredient types + Followers + Points stay a flat, bold, cartoonish EMOJI/STICKER set
(NOT the Ghibli hand).
- Do NOT attach a character or a dish mock-up as the icon reference — a painterly reference drags
  the icons painterly. Generate ONE icon first (start with FIG-ICON-meat), approve it, then attach
  THAT icon as the reference for the other 7 so all 8 match.
- Each icon keeps the SAME shape + SAME type colour as the SVG placeholder (colour-blind-safe by
  SHAPE, not hue). Transparent, square, legible at ~40 px. Output files: FIG-ICON-<type>.png
  (type = meat/tea/seafood/pantry/sugar/veg/follower/ticket).

>>> NEW ASSETS THIS REBUILD — illustrated VENDOR CARD BACKS (no humans).
The vendor-deck backs become illustrated shop scenes (replacing the code-drawn market motif),
with NO humans — just the shop/stall, in the Ghibli hand:
  - FIG-BACK-VEND-DAY   = a Taiwanese breakfast-shop (早餐店) storefront (soy-milk + egg-crepe
                          morning feel), warm morning gold.
  - FIG-BACK-VEND-NIGHT = a 夜市 night-market stall/lane, lanterns + neon.
Portrait card-back (750x1050). Kept SORTABLE face-down (breakfast-shop morning gold vs lantern
night — motif + palette). WIRING these PNGs into the renderer is a LATER step the orchestrator does
once the CD delivers the art — for now they are briefs only; the deterministic code back stays the
shipping playtest back. Prompts in mockup-kickoffs.md; direction in card-backs.md.

INGREDIENT ART CHANGES THIS REBUILD:
- Ingredients now FLOAT APART on a clean pale-cream ground — never plated, stacked, or touching
  ("on a plate, all touching" read as gross). Each item fresh, separated, Ghibli-delicious.
- MEAT (肉) is shown as RAW cuts (it's an ingredient) — pork belly / beef shank / poultry, fresh
  and glistening, appetising, NOT gory/gross.
- "Rice & Noodles"/"Pantry" is RENAMED to STAPLES (糧); its art shows rice + noodles + flour + tofu
  floating apart. (Data already renamed; icon file slug stays `pantry`.)

WHAT'S INSIDE (all current on-disk versions):
- mockup-kickoffs.md   — the paste-ready per-asset prompts. START HERE (Ghibli hand + icons +
                         the new vendor-back kickoffs).
- art-style.md         — the visual bible: the ONE look (now Ghibli), palette, line, mood, the
                         two-track illustration-vs-icon distinction.
- card-backs.md        — the card-BACK direction (day 早餐店 breakfast-shop; night 夜市 — no humans).
- character-art.md     — the six agents' portrait briefs (exaggerated-body-feature caricature).
- vendor-art.md        — the dish/vendor card art briefs (Ghibli-delicious food).
- tour-art.md          — the tour (Booking) hero briefs.
- map-board.md         — the shared table map backdrop brief + the EXACT DIMENSIONED LAYOUT SPEC
                         (canvas, region zones, card slots, tour row, clock, meeple areas — px +
                         canvas fractions) so the AI sizes every play position right the first time.
- character-boards.md  — the player-mat art notes.
- rulebook-figures.md  — the rulebook figure briefs.
- FIG-CHAR-influencer.png — OLD-look seed/context ONLY (do NOT use as the style reference).

BINDING RAILS (content, not AI-vs-human — still fully in force):
- 繁體 (Traditional Chinese) only, never Simplified. Secular; dignified locals — charming
  personality + body exaggeration, never ethnic caricature/mockery; faithful real dishes. English
  name first everywhere. (Icons carry NO text/glyphs at all.)
- The 2 Indigenous East dishes (E01 竹筒飯, E04 石板烤肉) + the warm-fixer framing of The Big Boss
  (老大) / The Old Councillor (里長伯) are consultant-gated before final/print — mock-ups are fine.

CURRENT TERMS (so the art reads on-theme):
- The sourcing action is "MARKET RUN" (the local market), not "Visit".
- The vendor-win action is "SIGN UP", not "Bribe".
